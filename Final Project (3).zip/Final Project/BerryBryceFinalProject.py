""" 
 This Python GUI was created to allow easy sales of bags of corn and soybeans to
 Those that want them. The initial window asks the user if they would like corn
 or soybeans. Both windows are the same, so lets say the user selects corn. Another
 window pops up with a type 'a' and type 'b' hybrid. The prices of both types are listed.
 The user can then select how many bags of each type they would like. Once the user selects
 how much they want, they select the submit button, and then a total price is displayed. The
 user can also switch to the beans option from this point, test another total of bags,
 or exit the program.
"""

#CORN WINDOW SECTION
#Define a new function to open the window
def open_win(): #opens the corn window
    new=Toplevel(win)
    new.geometry("750x250")
    new.title("Buying Corn")
    #create a label in new window
    Label(new, text="Select amount of bags",background=('#C89D7C'),font=('Helvetica 15 bold')).grid(row=0,columnspan=5)
    Label(new, text="Corn Hybrid A($5 per bag): ",background=('#C89D7C'), font=('Helvetica 14 bold')).grid(row=1,column=0)
    Label(new, text="Corn Hybrid B($6 per bag): ",background=('#C89D7C'), font=('Helvetica 14 bold')).grid(row=2,column=0)
    new.configure(background='#C89D7C')#changes the background color of the window
    
    #define function in the new window
    
    def calc1(): #the function for finding the price of the bags of corn
        x=answer1.get()
        y=answer2.get()
        if y or x !="":
            price1=int(x)
            price2=int(y)
            z=(price1 * 5)
            p=(price2 * 6)
            total=(z + p)
            final_label=Label(new,text=('Your total price is:','$',total,".00"),background=("#C89D7C"),font=('Helvetica 10')).grid() #Printing the total for the bags of corn
        else:
            print("Please input at least one.")
        
    #Buttons and packaging
    answer1=Entry(new, font=('Helvetica 17 bold'))#Entry box for corn hybrid A
    answer1.grid(row=1,column=1)
    answer2=Entry(new, font=('Helvetica 17 bold')) #Entry box for corn hybrid B
    answer2.grid(row=2,column=1)
    Label(new, text="Switch to beans:",background=('#C89D7C'),font=('Helvetica 12 bold')).grid()
    switch_button=Button(new,text="beans",command=open_win2).grid()#Switch to corn button
    Label(new, text="Exit Program:",background=('#C89D7C'),font=('Helvetica 11 bold')).grid()
    exit_button =Button(new, text="Exit",font=('Helvetica 12'),command=win.destroy).grid() #exit button
    config_price=Button(new,text="Calculate Price",command=calc1).grid(row=1,column=2) #button that calculates total price
    Label(new, text="Note: Please input at least zero and no negative integers.",background=('#C89D7C'),font=('Helvetica 8')).grid(row=3,column=1)

    #BEAN WINDOW SECTION
    #Define a new function to open the window
def open_win2():#opens the bean window
    new2=Toplevel(win)
    new2.geometry("750x250")
    new2.title("Buying Soybeans")
    
    #create a label in new window/color
    Label(new2, text="Select amount of bags",background=('#C89D7C'),font=('Helvetica 15 bold')).grid(row=0,columnspan=5) 
    Label(new2, text="Soybean Hybrid A($12 per bag):",background=('#C89D7C'), font=('Helvetica 17 bold')).grid(row=1,column=0)
    Label(new2, text="Soybean Hybrid B($8 per bag):",background=('#C89D7C'), font=('Helvetica 17 bold')).grid(row=2,column=0)
    new2.configure(background='#C89D7C')#changes the background color of the window

     #define function in the new window
    def calc2(): #the fuction for finding hte price of the bags of beans
        x=answer1.get()
        y=answer2.get()
        if y or x !="":
            price1=int(x)
            price2=int(y)
            z=(price1 * 12)
            p=(price2 * 8)
            total=(z + p)
            final_label=Label(new2,text=('Your total price is:','$',total,".00"),background=("#C89D7C"),font=('Helvetica 10')).grid() #printing the total for the bags of corn
        else:
            print("Please input at least one.")

    #Buttons and packaging
    answer1=Entry(new2, font=('Helvetica 17 bold')) #entry box 1
    answer1.grid(row=1,column=1)
    answer2=Entry(new2, font=('Helvetica 17 bold')) #entry box 2
    answer2.grid(row=2,column=1)

    Label(new2, text="Switch to corn:",background=('#C89D7C'),font=('Helvetica 12 bold')).grid()
    switch_button=Button(new2,text="corn",command=open_win).grid()#switch to beans button
    Label(new2, text="Exit Program:",background=('#C89D7C'),font=('Helvetica 11 bold')).grid()
    exit_button =Button(new2, text="Exit",font=('Helvetica 12'),command=win.destroy).grid() #exit button
    config_price=Button(new2,text="Calculate Price",command=calc2).grid(row=1,column=2)#button that calculates total price
    Label(new2, text="Note: Please input at least zero and no negative integers.",background=('#C89D7C'),font=('Helvetica 8')).grid(row=3,column=1)
    
#Primary (INITIAL WINDOW SECTION)
from tkinter import *
from tkinter import ttk
from functools import partial


#create an instance of tkinter frame or window
win=Tk() #Opens the initial window
#set geomerty of tkinter frame
win.geometry("750x250")
win.title("Buy Seeds")
#crete a label in new window
Label(win, text="Select Either Corn or Bean seed type to get started:",background=('#C89D7C'),
      font=("helvetica 17 bold")).grid()

#Adds the image(no image avaliable)

#Create a button to open a new window
corn_button=ttk.Button(win, text="Corn",command=open_win)#button that opens the corn window
corn_button.grid(row=0, column=2)
Soybeans_button=ttk.Button(win, text="Beans", command=open_win2)#button that opens the beans window
Soybeans_button.grid(row=1,column=2)
or_label=Label(win,text="Or, Close application:",background=('#C89D7C'), font=("helvetica 12")).grid()
exit_button =Button(win, text="Exit", command=win.destroy) #button that closes the application
exit_button.grid()
win.configure(background='#C89D7C') #changes the color of the background

win.mainloop()

